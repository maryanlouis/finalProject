<?php

$books =  array(
                
    "phil" => array("my girl" => 2.5, "the god delusion" => 3.5,
                    "tweak" => 3, "the shack" => 4,
                    "the birds in my life" => 2.5,
                    "new moon" => 3.5),
    
    "sameer" => array("the last lecture" => 2.5, "the god delusion" => 3.5,
                      "the noble wilds" => 3, "the shack" => 3.5,
                      "the birds in my life" => 2.5, "new moon" => 1),
    
    "john" => array("a thousand splendid suns" => 5, "the secret" => 3.5,
                    "tweak" => 1),
    
    "peter" => array("chaos" => 5, "php in action" => 3.5),
    
    "jill" => array("the last lecture" => 1.5, "the secret" => 2.5,
                    "the noble wilds" => 4, "the host: a novel" => 3.5,
                    "the world without end" => 2.5, "new moon" => 3.5),
    
    "bruce" => array("the last lecture" => 3, "the hollow" => 1.5,
                     "the noble wilds" => 3, "the shack" => 3.5,
                     "the appeal" => 2, "new moon" => 3),
    
    "tom" => array("chaos" => 2.5)
    
    
);

?>